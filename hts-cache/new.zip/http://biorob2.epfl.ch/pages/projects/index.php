<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>Project database</title>
<link href="//www.epfl.ch/css/epfl.css" media="all" rel="stylesheet" type="text/css"/>
<link href="//www.epfl.ch/css/sti.css" media="all" rel="stylesheet" type="text/css"/>
<link href="//www.epfl.ch/css/print.css" media="print" rel="stylesheet" type="text/css" />
<link href="//biorob2.epfl.ch/css/jahia2010.css" rel="stylesheet" type="text/css" />
<link href="//biorob2.epfl.ch/css/wp2018.css" rel="stylesheet" type="text/css" />
<style type="text/css">
#main-navigation .topnav li.homeLink a{background:url(//jahia-prod.epfl.ch/templates/epfl/img/icon_home_white.png) no-repeat 6px 6px!important;width:12px;height:18px;padding:4px 8px 2px 4px;}
#main-navigation .topnav li.homeLink a span{display:none;}
li.level1,li.level1 a{color:#fff!important;background-color:#000;}
li.level1 a:hover{color:#000!important;}
</style>
<script type="text/javascript" src="//www.epfl.ch/js/jquery-epfl.min.js"></script>
<script type="text/javascript">jQuery.noConflict();</script>
<script type="text/javascript" src="//www.epfl.ch/js/globalnav.js"></script>
<link rel="shortcut icon" href="//biorob2.epfl.ch/images/salamandre.ico" type="image/x-icon" /></head>
<body class="wpsti">
    <a name="top"></a>
    <div id="accessibility" class="hidden" title="École Polytechnique Fédérale de Lausanne - Quick access">
      <ul>
        <li><a href="//www.epfl.ch/accessibility.en.shtml" title="Specific informations for persons with disabilities" accesskey="0">Accessibility</a></li>
        <li><a href="//www.epfl.ch/" title="EPFL's homepage"  accesskey="1">Homepage</a></li>
        <li><a href="#navigation" accesskey="2">Navigation within EPFL sites</a></li>
        <li><a href="#main-navigation" accesskey="3">Navigation within this site</a></li>
        <li><a href="#search" id="searchlink" accesskey="4">Jump to search field</a></li>
        <li><a href="#content" accesskey="5">Jump to page content</a></li>
        <li><a href="mailto:webmaster@epfl.ch" accesskey="9">Technical contact</a></li>
      </ul>
    </div>

    <div id="header2013">
      <div id="nav-logo">
        <a href="//www.epfl.ch" title="EPFL homepage"><img src="//www.epfl.ch/img/epfl_small.png" /></a>
      </div>

      <div id="nav-menus">
        <a name="navigation"></a>
        <ul id="main-menus">
          <li class="portal menu" id="public-menu-link">
            <a class="main-link" href="//www.epfl.ch/navigate.en.shtml" title="Navigate by profile"><span>You</span> are</a>
            <div class="navigation-panel hidden" id="public-panel">
              <ul>
                <li class="group-2-cols">
                  <h3><a href="//futuretudiant.epfl.ch">Prospective students portal</a></h3>
                  <ul>
                    <li><a href="//bachelor.epfl.ch/studies">Bachelor</a>, <a href="//master.epfl.ch/page-94489-en.html">Master</a>, <a href="//phd.epfl.ch/home">PhD</a></li>
                    <li><a href="//futuretudiant.epfl.ch/mobility">Exchange student</a></li>
                  </ul>
                </li>
                <li class="group-2-cols">
                  <h3><a href="//studying.epfl.ch/en">Students portal</a></h3>
                  <ul>
                    <li><a href="//studying.epfl.ch/student_desk">Student services</a></li>
                    <li><a href="//memento.epfl.ch/academic-calendar/en">Academic calendar</a></li>
                  </ul>
                </li>
                <li class="group-2-cols last">
                  <h3><a href="//recherche.epfl.ch/en">Researchers portal</a></h3>
                  <ul>
                    <li><a href="//research-office.epfl.ch/funding">Research funding</a></li>
                    <li><a href="//actu.epfl.ch/search/research_awards/">Prizes and Awards</a></li>
                  </ul>
                </li>
                <li class="group-2-cols">
                  <h3><a href="//working.epfl.ch/staff-portal">Staff portal</a></h3>
                  <ul>
                    <li><a href="//rh.epfl.ch">Human resources</a></li>
                    <li><a href="//polylex.epfl.ch/page-26060-en.html">Polylex: laws, directives</a></li>
                  </ul>
                </li>
                <li class="group-2-cols">
                  <h3><a href="//entreprises.epfl.ch/business">Business portal</a></h3>
                  <ul>
                    <li><a href="//vpi.epfl.ch/en">Innovation &amp; Tech Transfer</a></li>
                    <li><a href="//vpi.epfl.ch/innovationpark">EPFL Innovation Park</a></li>
                  </ul>
                </li>
                <li class="group-2-cols last">
                  <h3><a href="//medias.epfl.ch/media-and-communications">Mediacorner</a></h3>
                  <ul>
                    <li><a href="//actu.epfl.ch/search/mediacom/?keywords=&amp;date_filter=all&amp;projects=190&amp;search=Rechercher">Press releases</a></li>
                    <li><a href="//mediacom.epfl.ch/epfl-magazine-en">EPFL Magazine</a></li>
                    <li><a href="//mediatheque.epfl.ch/">Image library</a></li>
                  </ul>
                </li>
                <li class="group-2-cols">
                  <h3><a href="//teaching.epfl.ch/en">Teaching portal</a></h3>
                  <ul>
                    <li><a href="//teaching.epfl.ch/cms/site/teaching/lang/en/preparer-un-cours_1">Courses management</a></li>
                    <li><a href="//teaching.epfl.ch/my-students_1">Students management</a></li>
                  </ul>
                </li>
                <li class="group-2-cols">
                  <h3><a href="//epflalumni.ch/">EPFL Alumni Portal</a></h3>
                  <ul>
                    <li><a href="//www.epflalumni.ch/avantages/formulaire-de-demande/">Join the community</a></li>
                    <li><a href="//www.epflalumni.ch/nos-evenements/">Alumni events</a></li>
                  </ul>
                </li>
                <li class="group-2-cols last">
                  <h3><a href="//artlab.epfl.ch/home">Science and Society</a></h3>
                  <ul>
                    <li><a href="//sps.epfl.ch/home">Science Outreach</a></li>
                    <li><a href="//artlab.epfl.ch/home">Culture/Art/Science - ArtLab</a></li>
                  </ul>
                </li>
              </ul>
              <div class="clear"></div>
            </div>
          </li>

          <li class="school menu" id="school-menu-link">
            <a class="main-link" href="//www.epfl.ch/navigate.en.shtml" title="Navigate by school"><span>By</span> school</a>
            <div class="navigation-panel hidden" id="school-panel">
              <ul>
                <li class="group-2-cols">
                  <h3><a href="//enac.epfl.ch/en" class="enac">Architecture, Civil and Environmental Engineering <acronym title="Environnement Naturel, Architectural et Construit">ENAC</acronym></a></h3>
                  <ul>
                    <li><a href="//enac.epfl.ch/en/architecture">Architecture</a></li>
                    <li><a href="//enac.epfl.ch/civil-engineering">Civil Engineering</a></li>
                    <li><a href="//enac.epfl.ch/environmental-engineering">Environmental Engineering</a></li>
                  </ul>
                </li>
                <li class="group-2-cols">
                  <h3><a href="//sb.epfl.ch/en" class="sb">Basic Sciences <acronym title="Sciences de Base">SB</acronym></a></h3>
                  <ul>
                    <li><a href="//sb.epfl.ch/chemistry">Chemistry and Chemical Engineering</a></li>
                    <li><a href="//sb.epfl.ch/mathematics">Mathematics</a></li>
                    <li><a href="//sb.epfl.ch/physics">Physics</a></li>
                  </ul>
                </li>
                <li class="group-2-cols last">
                  <h3><a href="//sti.epfl.ch/en" class="sti">Engineering <acronym title="Sciences et Techniques de l'Ingénieur">STI</acronym></a></h3>
                  <ul>
                    <li><a href="//sti.epfl.ch/electrical-engineering">Electrical Engineering</a></li>
                    <li><a href="//sti.epfl.ch/mechanical-engineering">Mechanical Engineering</a></li>
                    <li><a href="//sti.epfl.ch/materials-science-and-engineering">Materials Science and Engineering</a></li>
                    <li><a href="//sti.epfl.ch/microengineering">Microengineering</a></li>
                    <li><a href="//ibi.epfl.ch/">Bioengineering</a></li>
                  </ul>
                </li>
                <li class="group-2-cols">
                  <h3><a href="//ic.epfl.ch/en" class="ic">Computer and Communication Sciences <acronym title="Computer &amp; Communication Sciences">IC</acronym></a></h3>
                  <ul>
                    <li><a href="//ic.epfl.ch/computer-science">Computer Science</a></li>
                    <li><a href="//ic.epfl.ch/communication-systems">Communication Systems</a></li>
                    <li><a href="//ic.epfl.ch/data-science">Data Science</a></li>
                  </ul>
                </li>
                <li class="group-2-cols">
                  <h3><a href="//sv.epfl.ch/home" class="sv">Life Sciences <acronym title="Sciences de la Vie">SV</acronym></a></h3>
                  <ul>
                    <li><a href="//bioengineering.epfl.ch/">Bioengineering</a></li>
                    <li><a href="//sv.epfl.ch/BMI">Neuroscience Brain Mind &amp; Blue Brain</a></li>
                    <li><a href="//sv.epfl.ch/GHI">Global Health</a></li>
                    <li><a href="//sv.epfl.ch/ISREC">Cancer</a></li>
                  </ul>
                </li>
                <li class="group-2-cols last">
                  <h3><a href="//cdm.epfl.ch/homepage" class="cdm">Management of Technology <acronym title="Collège du Management de la Technologie">CDM</acronym></a></h3>
                  <ul>
                    <li><a href="//cdm.epfl.ch/mtei">Management, Technology &amp; Entrepreneurship</a></li>
                    <li><a href="//cdm.epfl.ch/itpp">Technology and Public Policy</a></li>
                    <li><a href="//sfi.epfl.ch">Swiss Finance Institute</a></li>
                  </ul>
                </li>
                <li class="group-2-cols">
                  <h3><a href="//cdh.epfl.ch/en" class="cdh">College of Humanities <acronym title="Collège des Humanités">CDH</acronym></a></h3>
                  <ul>
                    <li><a href="//cdh.epfl.ch/humanities-and-social-sciences">Human and Social Science</a></li>
                    <li><a href="//iags.epfl.ch">Area and Global Studies</a></li>
                    <li><a href="//cdh.epfl.ch/dh">Digital Humanities</a></li>
                  </ul>
                </li>
                <li class="group-2-cols">
                  <h3><a href="http://www.epfl.ae" class="ae">EPFL Middle East</a></h3>
                  <ul>
                    <li><a href="//master.epfl.ch/energy">Energy management and sustainability</a></li>
                  </ul>
                </li>
              </ul>
              <div class="clear"></div>
            </div>
          </li>

          <li class="short menu" id="brief-menu-link">
            <a class="main-link" href="//www.epfl.ch/navigate.en.shtml"><span>about</span> EPFL</a>
            <div class="navigation-panel hidden" id="brief-panel">
              <ul>
                <li class="group-2-cols">
                  <h3><a href="//information.epfl.ch/introduction"><acronym title="École polytechnique fédérale de Lausanne">EPFL</acronym></a></h3>
                  <ul>
                    <li><a href="//direction.epfl.ch/en/presentation">Direction</a></li>
                    <li><a href="//library.epfl.ch/en">Library</a></li>
                    <li><a href="//emploi.epfl.ch/en">Job offers</a></li>
                    <li><a href="//international.epfl.ch/homepage">International relations</a></li>
                  </ul>
                </li>
                <li class="group-2-cols">
                  <h3><a href="//futuretudiant.epfl.ch">Education</a></h3>
                  <ul>
                    <li><a href="//cms.epfl.ch/">Preparatory course <acronym title="Cours de Mathématiques Spéciales">CMS</acronym></a></li>
                    <li><a href="//bachelor.epfl.ch/studies">Bachelor</a>, <a href="//master.epfl.ch/en">Master</a>, <a href="//phd.epfl.ch/home">PhD</a></li>
                    <li><a href="http://www.formation-continue-unil-epfl.ch/en">Continuing education</a> (EPFL-UNIL)</li>
                    <li><a href="//moocs.epfl.ch/information">MOOCS</a></li>
                  </ul>
                </li>
                <li class="group-2-cols last">
                  <h3><a href="//recherche.epfl.ch/home">Research</a></h3>
                  <ul>
                    <li><a href="//research-office.epfl.ch/home">Research Office</a></li>
                    <li><a href="//recherche.epfl.ch/research-commission">Research Commission</a></li>
                    <li><a href="//recherche.epfl.ch/centers">Research centers</a></li>
                    <li><a href="//infoscience.epfl.ch/?ln=en"><acronym title="École polytechnique fédérale de Lausanne">EPFL</acronym> Publications</a></li>
                  </ul>
                </li>
                <li class="group-2-cols" style="clear: left;">
                  <h3><a href="//vpi.epfl.ch/en">Innovation &amp; Tech Transfer</a></h3>
                  <ul>
                    <li><a href="//vpi.epfl.ch/partnerships">Partnerships</a></li>
                    <li><a href="//vpi.epfl.ch/innogrants">Start-up</a></li>
                    <li><a href="http://www.alliance-tt.ch">Industrial liaison</a></li>
                    <li><a href="//tto.epfl.ch/hompage_eng">Technology transfer, patents</a></li>
                  </ul>
                </li>
                <li class="group-2-cols">
                  <h3><a href="//information.epfl.ch/discover-campus">EPFL Campus</a></h3>
                  <ul>
                    <li><a href="//fribourg.epfl.ch/en/home">Fribourg</a>, <a href="//geneva.epfl.ch/page-121741-en.html">Geneva</a>, <a href="//neuchatel.epfl.ch">Neuchâtel</a>, <a href="//valais.epfl.ch/Homepage">Valais</a></li>
                    <li><a href="//rolexlearningcenter.epfl.ch/page-34751-en.html">Rolex Learning Center</a></li>
                    <li><a href="//www.stcc.ch/en/home/">SwissTech Convention Center</a></li>
                    <li><a href="//artlab.epfl.ch/home">ArtLab</a></li>
                  </ul>
                </li>
              </ul>
              <div class="clear"></div>
            </div>
          </li>
        </ul>
      </div>

      <div id="nav-search">
        <div id="search-box">
          <a name="search"></a>
          <form name="search" action="https://search.epfl.ch/?" class="searchform" id="header_searchform">
            <input type="text" class="search" name="q" value="" autocomplete="off" id="header_searchfield" />
            <button type="submit" class="search-button local-color"  title="Search">Search</button>
          </form>
        </div>
      </div>
      <div class="clear"></div>
    </div>
<div id="main-content"><ul id="breadcrumbs"><li><a href="//www.epfl.ch/" title="EPFL Homepage">EPFL</a></li><li class="relative"><a class="externallink" href="//sti.epfl.ch/" target="_blank">STI</a></li><li class="relative"><a class="externallink" href="//ibi.epfl.ch/" target="_blank">IBI</a></li><li><a href="https://biorob.epfl.ch/">BioRob</a></li><li class="last"><a href="https://biorob.epfl.ch/students">Students</a></li></ul><div class="clear"></div><script type="text/javascript">
jQuery(document).ready(function() {
  jQuery("#dropdown36402").addClass("inpath");
  jQuery("#dropdown36402").addClass("current");
  jQuery("#updatesubmenu").addClass("inpath");
  jQuery("#deletesubmenu").addClass("inpath");
});
</script>
<h1><a href="https://biorob.epfl.ch/" title="BioRob">Biorobotics Laboratory&nbsp;<acronym title="Biorobotics Laboratory" class="local-color-text">BioRob</acronym></a></h1>
<header class="site-header"></header><div id="tools"><div class="button print"><a href="javaScript:window.print()"><button class="icon"></button><span class="label">Print</span></a></div></div><div id="content" class="content">
<link rel="stylesheet" type="text/css" href="/css/font-awesome.min.css">
<style type="text/css">
.projet {
  background: #E0E0FF;
  font-weight: bold;
}
.projet a {
  text-decoration: none;
  background-image: none;
}
.projtable {
  background: #F0F0FF;
}
.filter {
  background: #F0FFF0;
  border: dotted 1px #A0CFA0;
  margin-top: 12px;
  margin-bottom: 12px;
  padding-left: 12px;
  padding-right: 12px;
}
.warning {
  background: #ffccaa;
  border: dotted 1px #ffaa88;
  margin-top: 12px;
  margin-bottom: 12px;
  text-align: center;
  font-weight: 600;
}
.projsearch {
  background: #F0FFF0;
  border: dotted 1px #A0CFA0;
  margin-top: 12px;
  margin-bottom: 12px;
  padding-left: 12px;
  padding-right: 12px;
}
.col120 {
  width: 120px;
}
.foundkeyword, .foundkeyword:link, .foundkeyword:visited {
  color: red;
}
#keylist {
  display: none;
}
.noshow {
  display: none;
}
.desclink {
  text-align: right;
}
</style>
<script language="JavaScript">
<!--
function showDef(num)
{
  var x_a = document.getElementById("det"+num+"_a").style;
  var x_b = document.getElementById("det"+num+"_b").style;
  var x_c = document.getElementById("det"+num+"_c").style;
  var y = document.getElementById("dl"+num);
  if (x_a.display=="table-row") {
    x_a.display = "none";
    x_b.display = "none";
    x_c.display = "none";
    y.innerHTML = "Show details";
  } else {
    x_a.display = "table-row";
    x_b.display = "table-row";
    x_c.display = "table-row";
    y.innerHTML = "Hide details";
  }
}

function showKwList()
{
  var x = document.getElementById("keylist").style;
  var y = document.getElementById("kllink");
  if (x.display=="block") {
    x.display = "none";
    y.innerHTML = "Show complete list";
  } else {
    x.display = "block";
    y.innerHTML = "Hide list";
  }
}

function de(l)
{
  var r="";
  for (i=0; i<l.length; i++) r+=String.fromCharCode(l.charCodeAt(i)^3);
  return r;
}

function make_mail_link(mail, name)
{
  document.writeln("<a href=\"mailto:" + de(mail) +"\">" + name + "</a>");
}

// -->
</script>
<h2>Project Database</h2>
<p style="text-align: justify">This page contains the database of possible research projects for master and bachelor students in the <a href="http://birorob.epfl.ch/">Biorobotics Laboratory (BioRob)</a>. Visiting students are also welcome to join BioRob, but it should be noted that no funding is offered for those projects. To enroll for a project, please directly contact one of the assistants (directly in his/her office, by phone or by mail). Spontaneous propositions for projects are also welcome, if they are related to the research topics of BioRob, see the BioRob <a href="http://biorob.epfl.ch/research">Research</a> pages and the results of previous <a href="http://biorob.epfl.ch/page39405.html">student projects</a>.</p>
<div class="projsearch"><p><table width=100% border=0><tr><td>To limit the list to the projects matching a given keyword, click on it.</td><td align="right"><a id="kllink" href="javascript:showKwList();">Show complete list</a></td></tr></table>
</p><p id="keylist"><a href="/pages/projects/index.php?keyword=16">3D</a>, <a href="/pages/projects/index.php?keyword=29">Agility</a>, <a href="/pages/projects/index.php?keyword=45">Architecture</a>, <a href="/pages/projects/index.php?keyword=42">Balance Control</a>, <a href="/pages/projects/index.php?keyword=8">Bio-inspiration</a>, <a href="/pages/projects/index.php?keyword=38">Biped Locomotion</a>, <a href="/pages/projects/index.php?keyword=48">C#</a>, <a href="/pages/projects/index.php?keyword=4">C++</a>, <a href="/pages/projects/index.php?keyword=24">Coman</a>, <a href="/pages/projects/index.php?keyword=30">Compliance</a>, <a href="/pages/projects/index.php?keyword=21">Computational Neuroscience</a>, <a href="/pages/projects/index.php?keyword=32">Computer Science</a>, <a href="/pages/projects/index.php?keyword=46">Control</a>, <a href="/pages/projects/index.php?keyword=22">Data Evaluation</a>, <a href="/pages/projects/index.php?keyword=39">Data Processing</a>, <a href="/pages/projects/index.php?keyword=25">Dynamics Model</a>, <a href="/pages/projects/index.php?keyword=2">Electronics</a>, <a href="/pages/projects/index.php?keyword=3">Embedded Systems</a>, <a href="/pages/projects/index.php?keyword=26">Estimator</a>, <a href="/pages/projects/index.php?keyword=23">Experiments</a>, <a href="/pages/projects/index.php?keyword=13">FPGA</a>, <a href="/pages/projects/index.php?keyword=17">Feedback</a>, <a href="/pages/projects/index.php?keyword=33">Footstep Planning</a>, <a href="/pages/projects/index.php?keyword=51">GUI</a>, <a href="/pages/projects/index.php?keyword=35">Hybrid Balance Control</a>, <a href="/pages/projects/index.php?keyword=43">Image Processing</a>, <a href="/pages/projects/index.php?keyword=36">Inverse Dynamics</a>, <a href="/pages/projects/index.php?keyword=40">Kinect</a>, <a href="/pages/projects/index.php?keyword=27">Kinematics Model</a>, <a href="/pages/projects/index.php?keyword=41">Laser Scanners</a>, <a href="/pages/projects/index.php?keyword=5">Learning</a>, <a href="/pages/projects/index.php?keyword=49">Linux</a>, <a href="/pages/projects/index.php?keyword=12">Localization</a>, <a href="/pages/projects/index.php?keyword=6">Locomotion</a>, <a href="/pages/projects/index.php?keyword=20">Mechanical Construction</a>, <a href="/pages/projects/index.php?keyword=44">Motion Capture</a>, <a href="/pages/projects/index.php?keyword=52">Muscle modeling</a>, <a href="/pages/projects/index.php?keyword=34">Online Optimization</a>, <a href="/pages/projects/index.php?keyword=18">Optic Flow</a>, <a href="/pages/projects/index.php?keyword=53">Optimization</a>, <a href="/pages/projects/index.php?keyword=28">Probabilistics</a>, <a href="/pages/projects/index.php?keyword=14">Processor</a>, <a href="/pages/projects/index.php?keyword=9">Programming</a>, <a href="/pages/projects/index.php?keyword=54">Python</a>, <a href="/pages/projects/index.php?keyword=37">Quadruped Locomotion</a>, <a href="/pages/projects/index.php?keyword=11">Radio</a>, <a href="/pages/projects/index.php?keyword=31">Reflexes</a>, <a href="/pages/projects/index.php?keyword=50">Regenerative Motor Drive</a>, <a href="/pages/projects/index.php?keyword=1">Robotics</a>, <a href="/pages/projects/index.php?keyword=7">Simulator</a>, <a href="/pages/projects/index.php?keyword=10">Synchronization</a>, <a href="/pages/projects/index.php?keyword=47">Treadmill</a>, <a href="/pages/projects/index.php?keyword=15">VHDL</a>, <a href="/pages/projects/index.php?keyword=19">Vision</a></p>
</div>
<p><a href="#gr1">Amphibious robotics</a><br />
<a href="#gr2">Computational Neuroscience</a><br />
<a href="#gr3">Dynamical systems</a><br />
<a href="#gr4">Human-exoskeleton dynamics and control</a><br />
<a href="#gr5">Humanoid robotics</a><br />
<a href="#gr8">Miscellaneous</a><br />
<a href="#gr10">Mobile robotics</a><br />
<a href="#gr6">Modular robotics</a><br />
<a href="#gr9">Neuro-muscular modelling </a><br />
<a href="#gr7">Quadruped robotics</a><br />
</p><br>
<a name="gr1"></a>
<h3>Amphibious robotics</h3><p></p>
<table border="0" class="projtable" width="100%" cellspacing="0" cellpadding="2"><tr class="projet"><td valign="top"><a href="javascript:showDef(649);">649 &ndash; Can machine learning get improved by using a bio-inspired neural network?</a></td>
<td class="col120"><div class="desclink"><a id="dl649" href="javascript:showDef(649);">Show details</a></div></td></tr></table>
<table border="0" class="projtable" width="100%" cellspacing="0" cellpadding="2"><tr><td valign="top" class="col120">Category:</td><td colspan="2">semester project, master project (full-time), internship</td></tr>
<tr><td valign="top" class="col120">Keywords:</td><td colspan="2"><a href="/pages/projects/index.php?keyword=8">Bio-inspiration</a>, <a href="/pages/projects/index.php?keyword=21">Computational Neuroscience</a>, <a href="/pages/projects/index.php?keyword=5">Learning</a>, <a href="/pages/projects/index.php?keyword=18">Optic Flow</a>, <a href="/pages/projects/index.php?keyword=9">Programming</a>, <a href="/pages/projects/index.php?keyword=19">Vision</a></td></tr>
<tr class="noshow" id="det649_a"><td valign="top" class="col120">Type:</td><td colspan="2">10% theory, 90% software</td></tr>
<tr class="noshow" id="det649_b"><td valign="top" class="col120">Responsibles:</td><td colspan="2"><script>
make_mail_link("dvjoobvnf-afoofdbqgbCfseo-`k", "Guillaume Bellegarda");
</script><noscript>Guillaume Bellegarda</noscript>
 (MED 1 1024, phone: 37506)
<br /><script>
make_mail_link("{jbmd{jbl-ojvCfseo-`k", "Xiangxiao Liu");
</script><noscript>Xiangxiao Liu</noscript>
 (MED 1 1023, phone: 31367)
</td></tr>
<tr class="noshow" id="det649_c"><td valign="top" class="col120">Description:</td><td colspan="2">Thank you for your attention.  This project is very popular and we have already selected the student.  If you are interested in other projects related to Machine learning and quadruped robot, please contact Guillaume.  Also, if you are interested in swimming robots, brain and vision you can contact Xiangxiao.      BG:      The application of machine learning is a hot topic in engineering. In the implementation of machine learning, first, it is necessary to design the configuration of artificial neural networks (ANN, e.g. how many layers and how many nodes in each layer). Whereas, currently, there is no standard methodology to design such ANN.               Scientific question:           Nature always provides amazing inspirations to benefit the design of engineering systems. By the consideration of a particular task that we want to improve the behaviour of robotic optomotor response (OMR, describes a fish behaves tendency to following its surrounding visual motion) and rheotaxis (describes a fish has a tendency to swim against the current. OMR is one of the mechanism underling rheotaxis) by machine learning. Here comes a question: compared to arbitrarily chosen networks, can the learning process behaves better performance by using an ANN that inspired by the architecture of the animal brain network?              Hypothesis and estimation:           We hypotheses that by using an ANN that similar to the brain of the animal (zebrafish larvae), the learning process can be quicker and the final behaviour can with less error.              Scientific merit:     If the results correspond to our hypothesis, this study will emphasize the importance of the consideration of biological knowledge in machine learning.               Tasks of the student:            Currently, the neural networks underlying OMR has been identified and we have reproduced them in the Webots simulation. The works of the student include: 1. develop the machine learning process; 2. test different architectures of ANN 3. Compare their performance 4. write a manuscript. Other engineering tasks may also be included.<br/><br/><span class="fa fa-calendar"></span> Last edited: 03/08/2021</i></td></tr></table><table border="0" class="projtable" width="100%" cellspacing="0" cellpadding="2"><tr class="projet"><td valign="top"><a href="javascript:showDef(648);">648 &ndash; Robotic reproduction of OMRs and Rheotaxis</a></td>
<td class="col120"><div class="desclink"><a id="dl648" href="javascript:showDef(648);">Show details</a></div></td></tr></table>
<table border="0" class="projtable" width="100%" cellspacing="0" cellpadding="2"><tr><td valign="top" class="col120">Category:</td><td colspan="2">semester project, master project (full-time), bachelor semester project, internship</td></tr>
<tr><td valign="top" class="col120">Keywords:</td><td colspan="2"><a href="/pages/projects/index.php?keyword=8">Bio-inspiration</a>, <a href="/pages/projects/index.php?keyword=4">C++</a>, <a href="/pages/projects/index.php?keyword=3">Embedded Systems</a>, <a href="/pages/projects/index.php?keyword=49">Linux</a>, <a href="/pages/projects/index.php?keyword=18">Optic Flow</a>, <a href="/pages/projects/index.php?keyword=9">Programming</a>, <a href="/pages/projects/index.php?keyword=1">Robotics</a>, <a href="/pages/projects/index.php?keyword=19">Vision</a></td></tr>
<tr class="noshow" id="det648_a"><td valign="top" class="col120">Type:</td><td colspan="2">5% theory, 15% hardware, 80% software</td></tr>
<tr class="noshow" id="det648_b"><td valign="top" class="col120">Responsibles:</td><td colspan="2"><script>
make_mail_link("bofppbmgql-`qfpsjCfseo-`k", "Alessandro Crespi");
</script><noscript>Alessandro Crespi</noscript>
 (MED 1 1025, phone: 36630)
<br /><script>
make_mail_link("{jbmd{jbl-ojvCfseo-`k", "Xiangxiao Liu");
</script><noscript>Xiangxiao Liu</noscript>
 (MED 1 1023, phone: 31367)
</td></tr>
<tr class="noshow" id="det648_c"><td valign="top" class="col120">Description:</td><td colspan="2">Background:          When you go to a river, sometimes, you can see fishes are swimming against the current. This phenomenon is called rheotaxis. To achieve the rheotaxis, one strategy can be that the fishes maintain their visual image static. In science, such a strategy is called optomotor response (OMR). In Biorob, we are working on the reproduction of such phenomenon on both simulation and robots. In this student project, the student will work on the hardware part.                       Brief description of tasks:           Beyond the simulation, we are also planning to reproduce this behaviour on a newly developed physical fish-like robot named Envirobot V2.0. In this project, the student will develop the controlling program of the OMR (based on a framework established in past projects) and its user interface. After that, the students need to develop an experimental system to test the robotic OMRs. Besides these tasks, the student will also (may also) take care of the related paper works and engineering tasks in the grand project. (the quantity of the works will be adjusted to the semester/master/internship project)                                     To do this project, it is needed for the student to have the ability in embedded system programming (80%) and basic knowledge in hardware (mechanism and electronics 15%). In addition, it is necessary to learn the related theory in neuroscience (5 %).<br/><br/><span class="fa fa-calendar"></span> Last edited: 30/07/2021</i></td></tr></table><table border="0" class="projtable" width="100%" cellspacing="0" cellpadding="2"><tr class="projet"><td valign="top"><a href="javascript:showDef(662);">662 &ndash; More effecient searching of a fish-like robot by a simple fish brain? </a></td>
<td class="col120"><div class="desclink"><a id="dl662" href="javascript:showDef(662);">Show details</a></div></td></tr></table>
<table border="0" class="projtable" width="100%" cellspacing="0" cellpadding="2"><tr><td valign="top" class="col120">Category:</td><td colspan="2">semester project, internship</td></tr>
<tr><td valign="top" class="col120">Keywords:</td><td colspan="2"><a href="/pages/projects/index.php?keyword=8">Bio-inspiration</a>, <a href="/pages/projects/index.php?keyword=4">C++</a>, <a href="/pages/projects/index.php?keyword=21">Computational Neuroscience</a>, <a href="/pages/projects/index.php?keyword=12">Localization</a>, <a href="/pages/projects/index.php?keyword=6">Locomotion</a>, <a href="/pages/projects/index.php?keyword=9">Programming</a>, <a href="/pages/projects/index.php?keyword=1">Robotics</a>, <a href="/pages/projects/index.php?keyword=7">Simulator</a></td></tr>
<tr class="noshow" id="det662_a"><td valign="top" class="col120">Type:</td><td colspan="2">35% theory, 65% software</td></tr>
<tr class="noshow" id="det662_b"><td valign="top" class="col120">Responsible:</td><td colspan="2"><script>
make_mail_link("{jbmd{jbl-ojvCfseo-`k", "Xiangxiao Liu");
</script><noscript>Xiangxiao Liu</noscript>
 (MED 1 1023, phone: 31367)
</td></tr>
<tr class="noshow" id="det662_c"><td valign="top" class="col120">Description:</td><td colspan="2">Current challenge: To execute an action in robotic searching tasks, most of the methods are largely depending on the sensory feedback inputs. Whereas, sensory feedbacks may unavailable due to malfunction, disturbance, or lacking information. On such occasions, the robots must know how to execute an action even without sensory inputs and other cues.           Idea from biology: Such no-sensory searching challenges are also present in animals. Recent studies on the larvae brain [Dunn et al. 2016] provide ideas to cope with such challenges. It is known that zebrafish behave in three types of bout behaviour (left/right turn and forward swimming) when swimming in a dark environment. Whereas, interestingly, it is also found that the fishes behave a preference to generate the next bout by following the last bout (e.g. if the last bout is a left turn, the next bout has a high probability to be also a left turn). Such behaviour is the caution of ARTR in the hindbrain of the fish and can be modelled as a simple Markov chain. Scientists suggest that such behavioural strategy may help the fish explore the environment more efficiently (e.g. find food) and stay locally.        Scientific question:     We hypotheses that, in the case of without sensory feedback, such strategy may also help an underwater robot to do the searching and rescue task more efficiently compared to randomly movement.         Brief description of working:  In this project, the student is going to verify this hypothesis by conducting experiments in robotic fish simulation (Webots). First, the student will investigate the knowledge related to the decision making of animals. Second, she/he will construct a simulating environment to verify this hypothesis and evaluate the robotic behaviour.            The project requires the ability of [ability to understand publication in neuroscience] and [programming, Webot simulation].        References:    Dunn, Timothy W., et al. "Brain-wide mapping of neural activity controlling zebrafish exploratory locomotion." Elife 5 (2016): e12741.<br/><br/><span class="fa fa-calendar"></span> Last edited: 16/07/2021</i></td></tr></table><br>
<a name="gr4"></a>
<h3>Human-exoskeleton dynamics and control</h3><p></p>
<table border="0" class="projtable" width="100%" cellspacing="0" cellpadding="2"><tr class="projet"><td valign="top"><a href="javascript:showDef(639);">639 &ndash; Mechanical D&amp;D and V&amp;V for a Hand Exoskeleton</a></td>
<td class="col120"><div class="desclink"><a id="dl639" href="javascript:showDef(639);">Show details</a></div></td></tr></table>
<table border="0" class="projtable" width="100%" cellspacing="0" cellpadding="2"><tr><td valign="top" class="col120">Category:</td><td colspan="2">master project (full-time), internship</td></tr>
<tr><td valign="top" class="col120">Keywords:</td><td colspan="2"><a href="/pages/projects/index.php?keyword=30">Compliance</a>, <a href="/pages/projects/index.php?keyword=20">Mechanical Construction</a>, <a href="/pages/projects/index.php?keyword=1">Robotics</a></td></tr>
<tr class="noshow" id="det639_a"><td valign="top" class="col120">Type:</td><td colspan="2">20% theory, 60% hardware, 20% software</td></tr>
<tr class="noshow" id="det639_b"><td valign="top" class="col120">Responsible:</td><td colspan="2"><script>
make_mail_link("ov`b-qbmgbyylCfseo-`k", "Luca Randazzo");
</script><noscript>Luca Randazzo</noscript>
 (MED 0 1023, phone: 34183)
</td></tr>
<tr class="noshow" id="det639_c"><td valign="top" class="col120">Description:</td><td colspan="2"><p>    <p><b>Introduction</b></p>    At the BioRobotics laboratory at the École polytechnique fédérale de Lausanne (EPFL), we developed a novel hand exoskeleton with the main purpose of assisting independence and promoting intensive use during activities of daily living (ADL). The device was iteratively designed, developed and tested in collaboration with healthcare professionals and users with hand motor disabilities. Experimental results showed that the exoskeleton could help these users regain capabilities useful for independence in daily life that they had lost since their disabling accidents.   <p> <a href="https://www.epfl.ch/labs/biorob/research/rehabilitation/page-158960-en-html/">Click here for an overview of the project</a> </p>   </p>            <p>        <p><b>M.Sc. Thesis Proposal</b></p>        <p>The hand exoskeleton is composed of three main stages: (i) a wearable actuation stage, (ii) a bi-directional motion transmission stage to transmit the mechanical energy from the actuation stage to the user’s hand, and (iii) a wearable exoskeletal layer to exchange the mechanical energy with the wearer’s fingers – enabling to actively control their movements.</p>        <p>The objective of this Thesis is to perform closed-loop Verification and Validation (V&V) and Design and Development (D&D) activities on the three stages, to verify adherence to input design requirements and to improve the functionalities of the device based on the results of V&V.</p>        <p>This work will leverage on the knowledge on medical devices lifecycle matured within the laboratory, on the existing exoskeleton hardware concept, and will draw inspiration from state-of-the-art soft robotic exoskeletons / grippers to improve the existing device exploiting mechanically-compliant structures, materials and manufacturing methods.</p>        <p>The Thesis will be divided into three main work packages (WP):    <p>(WP1) Familiarization with existing hand exoskeleton, state-of-the-art literature, and medical devices lifecycle</p>    <p>(WP2) Mechanical Verification and Validation</p>    <p>(WP3) Mechanical Design and Development</p>    </p>        <p>Input design requirements are drawn from required performance during typical activities of daily living (e.g. autonomous eating with cutlery, grasping and holding a glass full of water, e.g.: fingertip forces ~10 N , ROM at fingers ~[70,100]° ), and from usability endpoints  (easy and quick donning/doffing procedures, prolonged wearing, comfort, reduced bulk and weight).</p>        <p>Expected outcomes include: (i) implementation of novel/improved designs of (some of) the stages of the device, (ii) assessments of performance through solid methodological and patient-centered approaches.<p>            <p>The Thesis will be conducted at the EPFL, with access to the following facilities:    <p>- Office location at the BioRobotics laboratory</p>    <p>- Personal access to manufacturing (e.g. Laser cutter; 3-axis CNC machine; ABS, PLA and Flexible FDM 3D printer; Thermoforming machine; Sewing machine; Lathe; SMD soldering equipment), and measuring (e.g. Vicon) tools</p>    <p>- On-demand access to EPFL services for professional manufacturing</p>    </p>            <p>    <p><b>Contact</b></p>    If interested, please contact: luca.randazzo@epfl.ch    </p>    </p><br/><br/><span class="fa fa-calendar"></span> Last edited: 01/07/2021</i></td></tr></table><table border="0" class="projtable" width="100%" cellspacing="0" cellpadding="2"><tr class="projet"><td valign="top"><a href="javascript:showDef(640);">640 &ndash; Electronics D&amp;D and V&amp;V for a Hand Exoskeleton</a></td>
<td class="col120"><div class="desclink"><a id="dl640" href="javascript:showDef(640);">Show details</a></div></td></tr></table>
<table border="0" class="projtable" width="100%" cellspacing="0" cellpadding="2"><tr><td valign="top" class="col120">Category:</td><td colspan="2">master project (full-time), internship</td></tr>
<tr><td valign="top" class="col120">Keywords:</td><td colspan="2"><a href="/pages/projects/index.php?keyword=2">Electronics</a>, <a href="/pages/projects/index.php?keyword=3">Embedded Systems</a>, <a href="/pages/projects/index.php?keyword=11">Radio</a>, <a href="/pages/projects/index.php?keyword=1">Robotics</a></td></tr>
<tr class="noshow" id="det640_a"><td valign="top" class="col120">Type:</td><td colspan="2">20% theory, 60% hardware, 20% software</td></tr>
<tr class="noshow" id="det640_b"><td valign="top" class="col120">Responsible:</td><td colspan="2"><script>
make_mail_link("ov`b-qbmgbyylCfseo-`k", "Luca Randazzo");
</script><noscript>Luca Randazzo</noscript>
 (MED 0 1023, phone: 34183)
</td></tr>
<tr class="noshow" id="det640_c"><td valign="top" class="col120">Description:</td><td colspan="2"><p>    <p><b>Introduction</b></p>    At the BioRobotics laboratory at the École polytechnique fédérale de Lausanne (EPFL), we developed a novel hand exoskeleton with the main purpose of assisting independence and promoting intensive use during activities of daily living (ADL). The device was iteratively designed, developed and tested in collaboration with healthcare professionals and users with hand motor disabilities. Experimental results showed that the exoskeleton could help these users regain capabilities useful for independence in daily life that they had lost since their disabling accidents.   <p> <a href="https://www.epfl.ch/labs/biorob/research/rehabilitation/page-158960-en-html/">Click here for an overview of the project</a> </p>   </p>            <p>        <p><b>M.Sc. Thesis Proposal</b></p>        <p>The objective of this Thesis is to perform closed-loop Verification and Validation (V&V) and Design and Development (D&D) activities on the the electronics components inside the device, to verify adherence to input design requirements and regulatory requirements, and to improve the functionalities of the device based on the results of V&V.</p>        <p>This work will leverage on the knowledge on medical devices lifecycle matured within the laboratory, on the existing exoskeleton electronics concepts, and will draw inspiration from state-of-the-art medical devices to improve the electronics of the device.</p>        <p>The Thesis will be divided into three main work packages (WP):    <p>(WP1) Familiarization with existing hand exoskeleton, state-of-the-art literature, and medical devices lifecycle</p>    <p>(WP2) Electronics Verification and Validation</p>    <p>(WP3) Electronics Design and Development</p>    </p>        <p>Expected outcomes include: (i) implementation of novel/improved designs of the device electronics, (ii) assessments of performance and compliance to regulatory requirements through solid methodological approaches.<p>            <p>The Thesis will be conducted at the EPFL, with access to the following facilities:    <p>- Office location at the BioRobotics laboratory</p>    <p>- Personal access to manufacturing (e.g. Laser cutter; 3-axis CNC machine; ABS, PLA and Flexible FDM 3D printer; Thermoforming machine; Sewing machine; Lathe; SMD soldering equipment), and measuring (e.g. Vicon) tools</p>    <p>- On-demand access to EPFL services for professional manufacturing</p>    </p>            <p>    <p><b>Contact</b></p>    If interested, please contact: luca.randazzo@epfl.ch    </p>    </p><br/><br/><span class="fa fa-calendar"></span> Last edited: 01/07/2021</i></td></tr></table><table border="0" class="projtable" width="100%" cellspacing="0" cellpadding="2"><tr class="projet"><td valign="top"><a href="javascript:showDef(641);">641 &ndash; Firmware D&amp;D and V&amp;V for a Hand Exoskeleton</a></td>
<td class="col120"><div class="desclink"><a id="dl641" href="javascript:showDef(641);">Show details</a></div></td></tr></table>
<table border="0" class="projtable" width="100%" cellspacing="0" cellpadding="2"><tr><td valign="top" class="col120">Category:</td><td colspan="2">master project (full-time), internship</td></tr>
<tr><td valign="top" class="col120">Keywords:</td><td colspan="2"><a href="/pages/projects/index.php?keyword=45">Architecture</a>, <a href="/pages/projects/index.php?keyword=4">C++</a>, <a href="/pages/projects/index.php?keyword=32">Computer Science</a>, <a href="/pages/projects/index.php?keyword=3">Embedded Systems</a>, <a href="/pages/projects/index.php?keyword=9">Programming</a>, <a href="/pages/projects/index.php?keyword=1">Robotics</a></td></tr>
<tr class="noshow" id="det641_a"><td valign="top" class="col120">Type:</td><td colspan="2">20% theory, 20% hardware, 60% software</td></tr>
<tr class="noshow" id="det641_b"><td valign="top" class="col120">Responsible:</td><td colspan="2"><script>
make_mail_link("ov`b-qbmgbyylCfseo-`k", "Luca Randazzo");
</script><noscript>Luca Randazzo</noscript>
 (MED 0 1023, phone: 34183)
</td></tr>
<tr class="noshow" id="det641_c"><td valign="top" class="col120">Description:</td><td colspan="2"><p>    <p><b>Introduction</b></p>    At the BioRobotics laboratory at the École polytechnique fédérale de Lausanne (EPFL), we developed a novel hand exoskeleton with the main purpose of assisting independence and promoting intensive use during activities of daily living (ADL). The device was iteratively designed, developed and tested in collaboration with healthcare professionals and users with hand motor disabilities. Experimental results showed that the exoskeleton could help these users regain capabilities useful for independence in daily life that they had lost since their disabling accidents.   <p> <a href="https://www.epfl.ch/labs/biorob/research/rehabilitation/page-158960-en-html/">Click here for an overview of the project</a> </p>   </p>            <p>        <p><b>M.Sc. Thesis Proposal</b></p>        <p>The objective of this Thesis is to perform closed-loop Verification and Validation (V&V) and Design and Development (D&D) activities on the the firmware components inside the device, to verify adherence to input design requirements and regulatory requirements, and to improve the functionalities of the device based on the results of V&V.</p>        <p>This work will leverage on the knowledge on medical devices lifecycle matured within the laboratory, on the existing exoskeleton electronics concepts, and will draw inspiration from state-of-the-art medical devices to improve the firmware of the device.</p>        <p>The Thesis will be divided into three main work packages (WP):    <p>(WP1) Familiarization with existing hand exoskeleton, state-of-the-art literature, and medical devices lifecycle</p>    <p>(WP2) Firmware Verification and Validation</p>    <p>(WP3) Firmware Design and Development</p>    </p>        <p>Expected outcomes include: (i) implementation of novel/improved designs of the device firmware, (ii) assessments of performance and compliance to regulatory requirements through solid methodological approaches.<p>            <p>The Thesis will be conducted at the EPFL, with access to the following facilities:    <p>- Office location at the BioRobotics laboratory</p>    <p>- Personal access to manufacturing (e.g. Laser cutter; 3-axis CNC machine; ABS, PLA and Flexible FDM 3D printer; Thermoforming machine; Sewing machine; Lathe; SMD soldering equipment), and measuring (e.g. Vicon) tools</p>    <p>- On-demand access to EPFL services for professional manufacturing</p>    </p>            <p>    <p><b>Contact</b></p>    If interested, please contact: luca.randazzo@epfl.ch    </p>    </p><br/><br/><span class="fa fa-calendar"></span> Last edited: 01/07/2021</i></td></tr></table><br>
<a name="gr6"></a>
<h3>Modular robotics</h3><p></p>
<table border="0" class="projtable" width="100%" cellspacing="0" cellpadding="2"><tr class="projet"><td valign="top"><a href="javascript:showDef(663);">663 &ndash; Prototyping of CPG networks on STM32 microcontrollers with various types of buses</a></td>
<td class="col120"><div class="desclink"><a id="dl663" href="javascript:showDef(663);">Show details</a></div></td></tr></table>
<table border="0" class="projtable" width="100%" cellspacing="0" cellpadding="2"><tr><td valign="top" class="col120">Category:</td><td colspan="2">master project (full-time)</td></tr>
<tr><td valign="top" class="col120">Keywords:</td><td colspan="2"><a href="/pages/projects/index.php?keyword=2">Electronics</a>, <a href="/pages/projects/index.php?keyword=3">Embedded Systems</a></td></tr>
<tr class="noshow" id="det663_a"><td valign="top" class="col120">Type:</td><td colspan="2">5% theory, 60% hardware, 35% software</td></tr>
<tr class="noshow" id="det663_b"><td valign="top" class="col120">Responsible:</td><td colspan="2"><script>
make_mail_link("bofppbmgql-`qfpsjCfseo-`k", "Alessandro Crespi");
</script><noscript>Alessandro Crespi</noscript>
 (MED 1 1025, phone: 36630)
</td></tr>
<tr class="noshow" id="det663_c"><td valign="top" class="col120">Description:</td><td colspan="2"><p>The goals of this project are:</p>          <ul>    <li>To create a simple custom board with a STM32 microcontroller and a few peripherals, designed to be easily interconnected to create a chain mimicking a modular robot</li>    <li>To test the board prototype, and assemble several copies for experiments</li>    <li>To implement a distributed central pattern generator (CPG) on the microcontollers, and evaluate its performance on various conditions, e.g. the number of nodes on the bus, and the type of communication bus used (typical examples will be CAN and Luos/Robus)</li>    <li>To design and implement a point-to-point communication protocol allowing the nodes to automatically deduce their position in the chain</li>   </ul><br/><br/><span class="fa fa-calendar"></span> Last edited: 16/08/2021</i></td></tr></table><br>
<a name="gr7"></a>
<h3>Quadruped robotics</h3><p>A small excerpt of possible projects is listed here. Highly interested students may also propose projects, or continue an existing topic.</p>
<table border="0" class="projtable" width="100%" cellspacing="0" cellpadding="2"><tr class="projet"><td valign="top"><a href="javascript:showDef(652);">652 &ndash; Integrating Learning-Based Control with MPC and CPGs</a></td>
<td class="col120"><div class="desclink"><a id="dl652" href="javascript:showDef(652);">Show details</a></div></td></tr></table>
<table border="0" class="projtable" width="100%" cellspacing="0" cellpadding="2"><tr><td valign="top" class="col120">Category:</td><td colspan="2">semester project, master project (full-time), bachelor semester project, internship</td></tr>
<tr><td valign="top" class="col120">Keywords:</td><td colspan="2"><a href="/pages/projects/index.php?keyword=8">Bio-inspiration</a>, <a href="/pages/projects/index.php?keyword=46">Control</a>, <a href="/pages/projects/index.php?keyword=5">Learning</a>, <a href="/pages/projects/index.php?keyword=6">Locomotion</a>, <a href="/pages/projects/index.php?keyword=53">Optimization</a>, <a href="/pages/projects/index.php?keyword=1">Robotics</a></td></tr>
<tr class="noshow" id="det652_a"><td valign="top" class="col120">Type:</td><td colspan="2">40% theory, 60% software</td></tr>
<tr class="noshow" id="det652_b"><td valign="top" class="col120">Responsible:</td><td colspan="2"><script>
make_mail_link("dvjoobvnf-afoofdbqgbCfseo-`k", "Guillaume Bellegarda");
</script><noscript>Guillaume Bellegarda</noscript>
 (MED 1 1024, phone: 37506)
</td></tr>
<tr class="noshow" id="det652_c"><td valign="top" class="col120">Description:</td><td colspan="2">Recent years have shown impressive locomotion control of dynamic systems through a variety of methods, for example with optimal control (MPC), machine learning (deep reinforcement learning), and bio-inspired approaches (CPGs). Given a system for which two or more of these methods exist: how should we choose which to use at run time? Should this depend on environmental factors, i.e. the expected value of a given state? Can this help with explainability of what exactly our deep reinforcement learning policy has learned?     In this project, the student will use machine learning to answer these questions, as well as integrate CPGs and MPC into the deep reinforcement learning framework. The methods will be validated on systems including quadrupeds and model cars first in simulation, with the goal of transferring the method to hardware.<br/><br/><span class="fa fa-calendar"></span> Last edited: 08/06/2021</i></td></tr></table><br>
<a name="gr10"></a>
<h3>Mobile robotics</h3><p></p>
<table border="0" class="projtable" width="100%" cellspacing="0" cellpadding="2"><tr class="projet"><td valign="top"><a href="javascript:showDef(658);">658 &ndash; Swarm Furniture Obstacle Avoidance for Smart-Living Environment Assisting Wheelchair Navigation</a></td>
<td class="col120"><div class="desclink"><a id="dl658" href="javascript:showDef(658);">Show details</a></div></td></tr></table>
<table border="0" class="projtable" width="100%" cellspacing="0" cellpadding="2"><tr><td valign="top" class="col120">Category:</td><td colspan="2">master project (full-time)</td></tr>
<tr><td valign="top" class="col120">Keywords:</td><td colspan="2"><a href="/pages/projects/index.php?keyword=46">Control</a>, <a href="/pages/projects/index.php?keyword=9">Programming</a></td></tr>
<tr class="noshow" id="det658_a"><td valign="top" class="col120">Type:</td><td colspan="2">50% theory, 50% software</td></tr>
<tr class="noshow" id="det658_b"><td valign="top" class="col120">Responsibles:</td><td colspan="2"><script>
make_mail_link("bmbpwbpjb-alolwmjhlubCfseo-`k", "Anastasia Bolotnikova");
</script><noscript>Anastasia Bolotnikova</noscript>
 (MED 1 1016, phone: 41216939075)
<br /><script>
make_mail_link("gjfdl-sbfyCfseo-`k", "Diego Felipe Paez Granados");
</script><noscript>Diego Felipe Paez Granados</noscript>
 (ME A3 395, phone: +41 21 693 10 6)
<br /><script>
make_mail_link("ovhbp-kvafqCfseo-`k", "Lukas Huber");
</script><noscript>Lukas Huber</noscript>
 (ME A3 485, phone: +41 21 693 78 2)
</td></tr>
<tr class="noshow" id="det658_c"><td valign="top" class="col120">Description:</td><td colspan="2">This project is a step towards the development of a modular control architecture for collaborative robots in smart-living environments. The goal is to develop a simulation environment of this fully smart home (mobile furniture) and implement a control framework for the modular robotic system to facilitate user’s navigation and obstacle avoidance through the smart home. The project will start by analyzing and drafting a swarm robot formation that could work in decentralised control based on LASA’s developed obstacle avoidance through modulated dynamical systems [1]. The resulting controller should plan motions either to move away or towards a person while respecting the environment’s constraints and avoiding collisions.      The test-bed simulation with modular robotic furniture will operate autonomously for increasing the efficient navigation of a pedestrian user or a smart wheelchair robot user (simulated semi-autonomous driving Qolo [2]). The resulting simulator and controller will serve as a baseline for enabling further development of the human-robot interaction framework to control specific behaviours of the modular robot furniture, such as a user commanding furniture to get closer or move further away.      This project is associated with the CIS Intelligent Assistive Robotics Collaboration Research Pillar. It is co-supervised by LASA and BioRob laboratories.         Approach:          1. Develop a test-bed environment (in Unity or Rviz) containing robotic furniture that incorporates physical/computational constraints and velocity control.          2. Implement an obstacle avoidance DS-based algorithm on each robot object acting independently [1].          3. Analyze the behaviour of the modular swarm acting independently and evaluate the performance of the swarm to provide a set of baseline results.          4. Formulate a swarm controller for enhancing group response towards enhancing/facilitating user motion in the smart environment.         Expected Experiences for the Student:      • Experience developing experimental test-bed for robot swarm simulation.      • Learning state-of-the-art motion control through time-invariant dynamical systems for mobile robots.       • Experience virtual robot motion planning for a robotic swarm.      • Experience virtual robot dynamic control.         References:          [1]  L. Huber, A. Billard, and J.-J. Slotine, “Avoidance of Convex and Concave Obstacles With Convergence Ensured Through Contraction,” IEEE Robotics and Automation Letters, vol. 4, no. 2, pp. 1462–1469, 2019. DOI: 10.1109/LRA.2019.2893676          [2]  D. F. Paez-Granados, H. Kadone, and K. Suzuki, “Unpowered Lower-Body Exoskeleton with Torso Lifting Mechanism for Supporting Sit-to-Stand Transitions,” in IEEE International Conference on Intelligent Robots and Systems, (Madrid), pp. 2755–2761, IEEE Xplorer, 2018. DOI:10.1109/IROS.2018.8594199<br/><br/><span class="fa fa-calendar"></span> Last edited: 18/06/2021</i></td></tr></table><table border="0" class="projtable" width="100%" cellspacing="0" cellpadding="2"><tr class="projet"><td valign="top"><a href="javascript:showDef(651);">651 &ndash; Autonomous Drifting on Scaled Vehicle Hardware</a></td>
<td class="col120"><div class="desclink"><a id="dl651" href="javascript:showDef(651);">Show details</a></div></td></tr></table>
<table border="0" class="projtable" width="100%" cellspacing="0" cellpadding="2"><tr><td valign="top" class="col120">Category:</td><td colspan="2">semester project, master project (full-time), bachelor semester project, internship</td></tr>
<tr><td valign="top" class="col120">Keywords:</td><td colspan="2"><a href="/pages/projects/index.php?keyword=4">C++</a>, <a href="/pages/projects/index.php?keyword=46">Control</a>, <a href="/pages/projects/index.php?keyword=2">Electronics</a>, <a href="/pages/projects/index.php?keyword=3">Embedded Systems</a>, <a href="/pages/projects/index.php?keyword=23">Experiments</a>, <a href="/pages/projects/index.php?keyword=53">Optimization</a></td></tr>
<tr class="noshow" id="det651_a"><td valign="top" class="col120">Type:</td><td colspan="2">10% theory, 60% hardware, 30% software</td></tr>
<tr class="noshow" id="det651_b"><td valign="top" class="col120">Responsible:</td><td colspan="2"><script>
make_mail_link("dvjoobvnf-afoofdbqgbCfseo-`k", "Guillaume Bellegarda");
</script><noscript>Guillaume Bellegarda</noscript>
 (MED 1 1024, phone: 37506)
</td></tr>
<tr class="noshow" id="det651_c"><td valign="top" class="col120">Description:</td><td colspan="2">Controlling vehicles at their limits of handling has significant implications from both safety and autonomous racing perspectives. For example, in icy conditions, skidding may occur unintentionally, making it desirable to safely control the vehicle back to its nominal working conditions. From a racing perspective, drivers of rally cars drift around turns while maintaining high speeds on loose gravel or dirt tracks.     In this project, the student will build a (1/16-1/5 scaled) vehicle hardware test bed to validate dynamic vehicle maneuvers involving both sustained (i.e. donuts) and transient (i.e. skid-parking) drifting. The nonlinear MPC producing such maneuvers has been validated in simulation (ROS/Gazebo). The project will involve full stack development: selecting hardware components (i.e. chassis, motor, microcontroller), physically building the system (i.e. possible 3D printing, mounting), and control and software (running the MPC on the microcontroller in C++). Potential extensions include integrating machine learning with the MPC, for example to facilitate transfer to drifting on new systems, surfaces, and environments.<br/><br/><span class="fa fa-calendar"></span> Last edited: 08/06/2021</i></td></tr></table><p>10 projects found.</p>
</div><div class="clear"></div><div id="footer"><ul>
<li><span class="link"><a href="https://biorob.epfl.ch/sitemap">Sitemap</a></span></li>
<li><a href="//www.epfl.ch/accessibility.en.shtml">Accessibility</a></li>
<li class="copyright">&copy; EPFL</li>
</ul></div>
</div>
<script type='text/javascript' src='https://biorob.epfl.ch/wp-content/themes/epfl-master/assets/js/navigation.js?ver=20151215'></script>
<script type='text/javascript' src='https://biorob.epfl.ch/wp-content/themes/epfl-master/assets/js/main.js'></script>
</body></html>
